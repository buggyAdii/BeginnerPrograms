#include<stdio.h>
main()
{
	int fn[10],ln[10],nm[20];
	printf("Enter Your First Name:");
	scanf("%s",fn);
	printf("Enter Your Last Name:");
	scanf("%s",ln);
	printf("Your Name is %s %s",fn,ln);
	
	
}
