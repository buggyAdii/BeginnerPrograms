#include<stdio.h>
main()
{
	int a,b,c;
	scanf("%d",&a);
	scanf("%d",&b);
	scanf("%d",&c);
	if(a==b or b==c or c==a)
	printf("0");
	else
	printf("1");
}
