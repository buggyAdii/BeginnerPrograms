#include<stdio.h>
int z;
ADD(int x,int y)
{
z=x+y;
return z;
}
SUB(int x,int y)
{
z=x-y;
return z;
}
MUL(int x,int y)
{
z=x*y;
return z;
}
DIV(int x,int y)
{
z=x/y;
return z;
}
main()
{
int num0,num1,sw,f1,f2,f3,f4;
printf("Enter First Number: ");
scanf("%d",&num0);
printf("Enter Second Number: ");
scanf("%d",&num1);
reset:
{
printf("\nEnter Your Choice:");
printf("\n1.Add 2.Substract 3.Multiply 4.Divide\n");
scanf("%d",&sw);
switch(sw)
{
case 1:
f1=ADD(num0,num1);
printf("\nThe answer is %d\n",f1);
break;
case 2:
f2=SUB(num0,num1);
printf("\nThe answer is %d\n",f2);
break;
case 3:
f3=MUL(num0,num1);
printf("\nThe answer is %d\n",f3);
break;
case 4:
f4=DIV(num0,num1);
break;
printf("\nThe answer is %d\n",f4);
default:
printf("\nWarning!!\nDon\"t mess with my code\n");
goto reset;
}
}
int k;
puts("\nEnter Choice: \n1. Continue: \t2. Restart \tX. Exit: ");
scanf("%d",&k);
if(k==1)
goto reset;
if(k==2)
return main();
}
