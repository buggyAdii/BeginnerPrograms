#include<stdio.h>
main()
{
int j=0;
do
{
printf("Value Of j is %d\n",j);
j++;
}while(j<=5);
}
