print("""Customer: Good Moring.
Owner: Good Morning,Sir. Welcome to the National Cheese Emporium.""")
print(1+1)
print("Hello\nWorld!")
print("print('print')")
input("Enter something here")
print("First String"+","+"second string")
