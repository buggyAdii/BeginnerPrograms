#include<stdlib.h>
#include<stdio.h>
int main()
{

int a,i=0;
{
scanf("%d",&a);
}
do{
printf("*\n");
i++;}while(i<a);
return 0;
}

