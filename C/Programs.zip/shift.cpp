#include<stdio.h>
main()
{
	int a=0125;
	printf("%d",a+5);
}
