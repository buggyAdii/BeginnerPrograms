#include<stdio.h>
main()
{
    int c=0;
    while(c<-6)
    {
    printf("Not Ok\n");
        c=c+1;
    }
}
