
#include<stdio.h>
main()
{
int m,n;
scanf("%d",&m);
scanf("%d",&n);
if(m%n!=0)
printf("0");
else
printf("%d",m/n);
}
