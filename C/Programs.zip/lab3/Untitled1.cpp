#include<stdio.h>
main()
{
int i=0;
while(i<5)
{
printf("ghandu madharchod\n");
i++;
}
}
